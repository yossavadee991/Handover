# Ansible Automation

[[_TOC_]]

This service have 2 VM
1. BKK-Ansible-AWX: 10.244.35.62 / admin P@ssw0rd$NT
2. BKK-GitLab: 10.244.35.64 / your AD Account




#### Service Architecture
![image.png](images/ansiblearchitect.png)

#### What is Ansible AWX Tower

Ansible AWX Tower is an opensource automation tool 

#### How Ansible works
In Ansible, there are two categories of computers: the control node and managed nodes. The control node is a computer that runs Ansible AWX Tower. A managed node is any device being managed by the control node.

Ansible works by connecting to nodes (clients, servers, or whatever you're configuring) on a network, and then sending a small program called an Ansible module to that node. Ansible executes these modules over SSH and removes them when finished. The only requirement for this interaction is that your Ansible control node has login access to the managed nodes. SSH keys are the most common way to provide access, but other forms of authentication are also supported.

Connection to device
SSH for linux,ubuntu or network device
WinRM for window server

#### Ansible playbooks
A playbook is a configuration file written in YAML format that provides instructions for what needs to do on managed node to meet your desired. Playbooks are meant to be simple, human-readable, and self-documenting. They are also idempotent, meaning that a playbook can be run on a system at any time without having a negative effect upon it. If a playbook is run on a system that's already properly configured and in its desired state, then that system should still be properly configured after a playbook runs.


We use Ansible tower to automate our routine task (Server maintenance) to reduce human-error, reduce time to do it

You can find Service Maintenance playbook here: http://10.244.35.64/authakarn/server-maintenance

#### Server Maintenance workflow playbook

Let me explain you about playbook workflow when you run the task

Example. Run template "OA1 Every month on First Friday" on Ansible AWX Tower


1.When you run the template on Ansible AWX. it will pull the playbook from gitlab (http://10.244.35.64/authakarn/server-maintenance/-/tree/master)

2.In template "OA1 Every month on First Friday" have a inventory that contain 2 server 

![image.png](images/oainventory.png)

Ansible will get the name of server and check it in "service.yaml" and "listcommand.yaml".

![image.png](images/listservice.png)

3.If found,It will get the list parameter that under their name in above files and put in the task

4.They will do the task to pre check service if they have service to check and do task run command if they have the command to run

![image.png](images/precheckservice.png)

5.Reboot task

![image.png](images/reboot.png)

6.They will run the post check service 

![image.png](images/postcheckservice.png)

7.After all above task, It will compare the existing pre check service and existing post check service. If it equal,The task on ansible will show OA successfully,If not it will show fail

![image.png](images/compare.png)

#### How to operate the OA Server Maintenance task

You can see the work instruction on topdesk KI 0344 Server maintenance with Ansible script
