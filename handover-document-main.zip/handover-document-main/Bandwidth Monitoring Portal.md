# Bandwidth Monitoring Portal
[[_TOC_]]


This service have 2 VM to provide service for customer
1. BKK-Netflow (PRTG): 10.244.57.79 
2. BKK-Grafana: 10.244.57.83:3000 / https://nms.snt.co.th:3000
credential for web-gui
user: admin
password: P@ssw0rd$NT
### Service Architecture

![Service Diagram](images/Service Architecture.jpg)

We use BKK-Netflow (PRTG) to collect Netflow traffic from our router by create “sensor” on PRTG Web GUI and use Grafana to pulling the traffic data via API to visualize the data into graph dashboard
![PRTG](images/prtgsensor.png "prtg")

### How to create sensor 
you can follow on KI 0225 Adding sensors to PRTG for customer bandwidth monitoring on topdesk



After create sensor. Let's go to Grafana to create dashboard

### How to create dashboard
When new customer onboard. We have to create dashboard by following below step:

##### 1.Create organization

Go to Server Admin -> Orgs Click New org then fill in the customer name and create


![Org](images/create org1.png "org1") ![Org](images/create org2.png "org2")

##### 2.Create datasource

Go to Orgs that you want to create datasource and go to Configuration -> Datasource -> Add Datasource

![image.png](images/image.png)
![image.png](images/image1.png)

Select Datasource name "PRTG" and setting configuration as below

![image-1.png](images/image-1.png)

Passhash for grafana api is: 3252075592

After finish configuration. Save & Test You should see the message with green box as picture

##### 3.Create account for customer

Go to Server Admin -> Users. Then Click New user. Fill in the information and create. After that, Click on the user that you created and go to Add user to organization and select customer orgs and save

![image-2.png](images/image-2.png)

![image-3.png](images/image-3.png)

![image-4.png](images/image-4.png)

##### 4.Create dashboard

Go to Create -> Dashboard and add new panel. We have to create 2 dashboard for 1 customer 1.Inter-Traffic and 2.Domestic Traffic

![image-5.png](images/image-5.png)

Select datasource and choose 8 sensor that we create on PRTG

![image-6.png](images/image-6.png)

Number of query have to be "8" and configuration will be like this

Inter-Traffic Graph

| A            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R1 |
| Sensor | XXX-TRUE-INTER-Inbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| B            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R2 |
| Sensor | XXX-TRUE-INTER-Inbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| C            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R1 |
| Sensor | XXX-UIH-INTER-Inbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| D            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R2 |
| Sensor | XXX-UIH-INTER-Inbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| E            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R1 |
| Sensor | XXX-TRUE-INTER-Outbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| F            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R2 |
| Sensor | XXX-TRUE-INTER-Outbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| G            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R1 |
| Sensor | XXX-UIH-INTER-Outbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| G            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R2 |
| Sensor | XXX-UIH-INTER-Outbound| Channel | Total (speed) |
| Multipilier | 0.008 |

After finish create graph.Then go to tab "Transformation" and Select Add field from calulation to summary all graph in to inbound traffic and outbound traffic.

![image-7.png](images/image-7.png)

And configuration should be like this.

![image-8.png](images/image-8.png)

After that Click "Add transformation" and select "Organize fields" to manage visibility for line of graph. Setting should be like this.

![image-9.png](images/image-9.png)

Finally, Panel Setting on the right side should be like this.

![image-10.png](images/image-10.png)![image-11.png](images/image-11.png)![image-12.png](images/image-12.png)

Then, Apply and save. You will get Inter traffic. And You have to create domestic traffic graph also.

Domestic-Traffic Graph

| A            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R1 |
| Sensor | XXX-TRUE-DOMESTIC-Inbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| B            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R2 |
| Sensor | XXX-TRUE-DOMESTIC-Inbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| C            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R1 |
| Sensor | XXX-UIH-DOMESTIC-Inbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| D            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R2 |
| Sensor | XXX-UIH-DOMESTIC-Inbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| E            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R1 |
| Sensor | XXX-TRUE-DOMESTIC-Outbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| F            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R2 |
| Sensor | XXX-TRUE-DOMESTIC-Outbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| G            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R1 |
| Sensor | XXX-UIH-DOMESTIC-Outbound| Channel | Total (speed) |
| Multipilier | 0.008 |

| G            |  | ||
|-------------|------------|------------|------------|
| Query Mode | Metrics |
| Group | Network Infrastructure | Host | SNT-R2 |
| Sensor | XXX-UIH-DOMESTIC-Outbound| Channel | Total (speed) |
| Multipilier | 0.008 |

After finish create graph.Then go to tab "Transformation" and Select Add field from calulation to summary all graph in to inbound traffic and outbound traffic .

![image-7.png](images/image-7.png)

And configuration should be like this.

![image-8.png](images/image-8.png)

After that Click "Add transformation" and select "Organize fields" to manage visibility for line of graph. Setting should be like this.

![image-9.png](images/image-9.png)

Finally, Panel Setting on the right side should be like this.

![image-10.png](images/image-10.png)![image-11.png](images/image-11.png)![image-12.png](images/image-12.png)

After finishing all of above you should be get the graph for customer like this.

![image-13.png](images/image-13.png)

********** Dont' forget to save the dashboard by click the save icon on the upper-right screen. *****************


##### 5.Create API key for dashboard exporter

Select the Orgs that you want to create API key then go to Configuration -> API Keys.

![image-14.png](images/image-14.png) ![image-15.png](images/image-15.png)

Input the key name and set the role to viewer after that click add.

![image-16.png](images/image-16.png) 

Copy the key to notepad because you can't see it again after you close this dialog box.

![image-17.png](images/image-17.png)

Go to customer dashboard and click "Dashboard Settings" on upper-right screen.

![image-18.png](images/image-18.png)

Go to menu "Link" and click new and set the configuration like this.

![image-19.png](images/image-19.png)

For Url please use this pattern https://nms.snt.co.th:8686/api/v5/report/{{Dashboard UID}}?apitoken={{API Key that you created before}

You can find Dashboard UID by check on each customer dashboard Url as below.

![image-20.png](images/image-20.png)

Finally save and test by click on Button that locate on the upper-right of the graph.

If it no problem, You will get the report as pdf file.

![image-21.png](images/image-21.png)

Finally, You already done with grafana.

### Bandwidth usage monthly report

On the first day on month, We generate the report for each customer and sent it to file share server \\fshare\netops-data$\04.Document\Reports\NETOPS monthly KPI Report\Monthly Customer Bandwidth Usage

The report generate by bash script in grafana server. The script stored at this path /home/somprasong/Customer_Bandwidth_Report/bwreport.sh

When new internet customer onboarding. You have 2 thing to do

Edit script by type "nano bwreport.sh"

![image-22.png](images/image-22.png)

You have to add new customer dashboard uid in array as above and add api key of new customer.

save file and it's done

### How to re-new ssl certificate

Prepare ssl certificate file and naming certificate file to "nms.crt" and "nms.key" and store file in path "/etc/grafana/"

![image-23.png](images/image-23.png)

After that reboot server and when it booted. Check ssl on grafana website

